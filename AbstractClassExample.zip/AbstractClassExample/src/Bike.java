
public abstract class Bike {

	public abstract void tire();

	public abstract void engine();

	public abstract void breaks();

	public void seat() {
		System.out.println("Seat");
	}

	public void Headlight() {
		System.out.println("Headlight");
	}
}
