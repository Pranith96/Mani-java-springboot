
public class MainMethod {

	public static void main(String[] args) {
		R15Bike bike = new R15Bike();
		bike.breaks();
		bike.engine();
		bike.handle();
		bike.Headlight();
		bike.seat();
		bike.tire();
		bike.wiring();
	}
}
