
public class R15Bike extends MotorBike {

	@Override
	public void breaks() {
		System.out.println("breaks");
	}

	@Override
	public void handle() {
		System.out.println("Handle");
	}

}
