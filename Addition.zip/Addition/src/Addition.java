
public class Addition {

	public static void main(String[] args) {
		System.out.println("hello..!!");
		hello();
	}
	
	public static void hello() {
		System.out.println("hello world..!!");
	}
}
