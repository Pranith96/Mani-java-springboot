
public class Addition2 {

	public static void hi() {
		System.out.println("hello..!!");
		
	}
}
