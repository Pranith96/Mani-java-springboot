
public class Addition {

	public void add(int a, int b) {
		int c = a + b;
		System.out.println(c);
	}

	public void hello() {
		System.out.println("Hello Welcome..!!");
	}

}
