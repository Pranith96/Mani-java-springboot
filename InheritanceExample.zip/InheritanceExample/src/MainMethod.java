
public class MainMethod {

	public static void main(String[] args) {
		
		Summation summation = new Summation();
		summation.sum();
		summation.print();
		summation.add(5, 5);
		summation.hello();
	}

}
