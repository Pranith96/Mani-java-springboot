
public class Summation extends Addition {

	public void print() {
		System.out.println("Print data");
	}
	
	public void sum() {
		System.out.println("Sum");
	}
}
