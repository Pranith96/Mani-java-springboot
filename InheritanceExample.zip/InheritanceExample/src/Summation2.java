
public class Summation2 extends Addition{

	public void display() {
		System.out.println("display data");
	}
	
	public void sub() {
		System.out.println("Sub");
	}
}
