
public interface Bike {

	public void breaks();

	public void tire();

	public void handle();

	public void engine();
	
	public void wiring();

}
