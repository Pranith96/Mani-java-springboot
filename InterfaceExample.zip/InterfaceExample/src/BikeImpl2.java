
public class BikeImpl2 implements Bike {

	@Override
	public void breaks() {
		System.out.println("breaks2");
	}

	@Override
	public void tire() {
		System.out.println("tire2");
	}

	@Override
	public void handle() {
		System.out.println("handle2");
	}

	@Override
	public void engine() {
		System.out.println("engine2");
	}

	@Override
	public void wiring() {
		System.out.println("wiring2");
	}

}
